/* ipqueue module */
/* Copyright 2002, WatchGuard Technologies, Inc. */
/* Released under the GPL */

#include <Python.h>
#include <linux/netfilter.h>
#include <libipq.h>
#include <netinet/in.h>
#include <errno.h>

#ifndef DATALEN
#define DATALEN 65535
#endif

/* IPQ objects */

staticforward PyTypeObject IPQType;
static PyObject *ipqueue_error;

typedef struct {
    PyObject_HEAD
    struct ipq_handle *handle;
    char *buf;
} IPQObject;

/** Constructor */
char new_IPQObject__doc__[] = "\
new(mode=IPQ_COPY_META) -> IPQ -- create a new IPQ listener\n\
Opens a connection to the kernel's ip_queue module.  This will\n\
allow a user-space process to handle packets with a target of\n\
QUEUE.\n\
\n\
mode can be either IPQ_COPY_META, or IPQ_COPY_PACKET.  In the latter\n\
case, the entire packet will be copied into the payload of the tuple\n\
returned from read().  Otherwise, the payload will always be None.\n\
";
static PyObject*
new_IPQObject(PyObject *self, PyObject *args)
{
    IPQObject* IPQ;
    long lmode;

    lmode = IPQ_COPY_META;
    if (!PyArg_ParseTuple(args, "|i:new", &lmode)) {
	return NULL;
    }

    if ((IPQ_COPY_META != lmode) && (IPQ_COPY_PACKET != lmode)) {
	PyErr_SetString(PyExc_ValueError, "invalid value for mode");
	return NULL;
    }

    IPQ = PyObject_New(IPQObject, &IPQType);
    if (! IPQ) {
	return NULL;
    }
    
    IPQ->buf = (char *)malloc(DATALEN * sizeof(char));
    if (! IPQ->buf) {
	PyErr_NoMemory();
	Py_DECREF(IPQ);
	return NULL;
    }

    IPQ->handle = ipq_create_handle(0, PF_INET);
    if (! IPQ->handle) {	
	PyErr_SetString(ipqueue_error, ipq_errstr());
	Py_DECREF(IPQ);
	free(IPQ->buf);
	return NULL;
    }

    {
	int ret;
	
	ret = ipq_set_mode(IPQ->handle, (u_int8_t)lmode, DATALEN);
	if (-1 == ret) {
	    PyErr_SetString(ipqueue_error, ipq_errstr());
	    free(IPQ->buf);

	    ret = ipq_destroy_handle(IPQ->handle);
	    if (-1 == ret) {
		/* We can't raise a second exception.  I'm not sure what
		 * the best thing to do is here, since potentially
		 * memory could be leaked. */
		ipq_perror("Error in constructor: ipq_destroy_handle");
	    }

	    /* So like, this causes a segfault.  I guess the reference
	       count hasn't been incremented yet, or something. */
	    /* Py_DECREF(IPQ); */
	    return NULL;
	}
    }
    
    return (PyObject *)IPQ;
}

/** Destructor */
static void
IPQ_dealloc(PyObject *self)
{
    int ret;
    IPQObject* IPQ = (IPQObject *)self;
    
    if (IPQ->handle) {
	ret = ipq_destroy_handle(IPQ->handle);
	if (-1 == ret) {
	    /* We can't raise an exception in a destructor. Again, I'm
	     * not sure what the best course of action is if freeing up
	     * the handle fails. */
	    ipq_perror("Error in destructor: ipq_destroy_handle");
	}
	IPQ->handle = NULL;
    }
    if (IPQ->buf) {
	free(IPQ->buf);
	IPQ->buf = NULL;
    }
    PyObject_Del(self);
}

char IPQ_fileno__doc__[] = "\
fileno() -> integer -- return the fileno of the ip_queue socket\n\
Every ip_queue has a socket through which it reads and writes\n\
data.  This socket has a file descriptor associated with it which\n\
can be used with select or poll, just like any other socket.\n\
";
static PyObject *
IPQ_fileno(PyObject *self, PyObject *args)
{
    IPQObject* IPQ = (IPQObject *)self;

    if (!PyArg_ParseTuple(args, "")) {
	return NULL;
    }

    return Py_BuildValue("i", (int)IPQ->handle->fd);
}


char IPQ_read__doc__[] = "\
read() -> big-ass tuple -- read a packet\n\
The tuple is:\n\
\n\
  (id,		# ID of queued packet\n\
   mark,	# Netfilter mark value\n\
   arr,		# Packet arrival time (sec, +usec)\n\
   hook,	# Netfilter hook we rode in on\n\
   indev,	# Name of incoming interface\n\
   outdev,	# Name of outgoing interface\n\
   proto,	# Hardware protocol\n\
   type,	# Hardware type\n\
   hw_addr,	# Hardware address\n\
   payload)	# Optional packet data\n\
\n\
You'll need the id to set the verdict.  Don't ask me what all the rest\n\
of those fields are, though.\n\
";
static PyObject *
IPQ_read(PyObject *self, PyObject *args)
{
    IPQObject* IPQ = (IPQObject *)self;
    int buflen;
    int msgtype;
    
    if (!PyArg_ParseTuple(args, "")) {
	return NULL;
    }

    buflen = ipq_read(IPQ->handle, IPQ->buf, DATALEN, 0);
    if (-1 == buflen) {
	PyErr_SetString(ipqueue_error, ipq_errstr());
	return NULL;
    }
    
    msgtype = ipq_message_type(IPQ->buf);
    switch (msgtype) {
	case NLMSG_ERROR:
	    {
		int err;
		
		err = ipq_get_msgerr(IPQ->buf);
		PyErr_SetString(ipqueue_error, strerror(err));
		return NULL;
	    }
	    break;
	case IPQM_PACKET:
	    {
		ipq_packet_msg_t *packet;

		packet = ipq_get_packet(IPQ->buf);
		if (! packet) {
		    /* The man page seems to think this will never
		     * return an error, but we can't take chances */
		    PyErr_SetString(ipqueue_error, "ipq_get_packet failed");
		    return NULL;
		}
		return Py_BuildValue("(L,L,(l,l),l,s,s,i,i,s#,s#)",
				     (LONG_LONG)packet->packet_id,
				     (LONG_LONG)packet->mark,
				     (long)packet->timestamp_sec,
				     (long)packet->timestamp_usec,
				     (long)packet->hook,
				     (char *)packet->indev_name,
				     (char *)packet->outdev_name,
				     (int)ntohs(packet->hw_protocol),
				     (int)packet->hw_type,
				     (char *)packet->hw_addr,
				     (int)packet->hw_addrlen,
				     (char *)packet->payload,
				     (int)packet->data_len);
	    }
	    break;
    }
    
    PyErr_SetString(ipqueue_error, "Unknown error in ipq_message_type");
    return NULL;
}

char IPQ_set_verdict__doc__[] = "\
set_verdict(id, verdict, buf=None) -> integer -- Set the verdict\n\
Using the id returned by read(), sets the verdict on the packet.\n\
Verdict may be one of NF_ACCEPT, or NF_DROP.  If buf is not NULL, it\n\
should contain the rewritten contents of the packet to send out.  If\n\
NULL, the original packet is sent out unaltered.\n\
";
static PyObject *
IPQ_set_verdict(PyObject *self, PyObject *args)
{
    IPQObject* IPQ = (IPQObject *)self;
    LONG_LONG id;
    int verdict;
    size_t data_len;
    unsigned char *buf;
    int ret;

    data_len = 0;
    buf = NULL;
    if (!PyArg_ParseTuple(args, "Li|s#", &id, &verdict, &buf, &data_len)) {
	return NULL;
    }

    if ((NF_ACCEPT != verdict) && (NF_DROP != verdict)) {
	PyErr_SetString(PyExc_ValueError, "invalid value for verdict");
	return NULL;
    }

    ret = ipq_set_verdict(IPQ->handle, id, verdict, data_len, buf);
    if (-1 == ret) {
	PyErr_SetString(ipqueue_error, ipq_errstr());
	return NULL;
    }

    /* The man page says the return value is positive, but doesn't say
     * what it signifies.  So we return it and hope it might be useful
     * to someone someday. */
    return Py_BuildValue("i", ret);
}

/* Object attr lookup */

static PyMethodDef IPQ_methods[] = {
    {"fileno",      IPQ_fileno,      METH_VARARGS, IPQ_fileno__doc__},
    {"read",        IPQ_read,        METH_VARARGS, IPQ_read__doc__},
    {"set_verdict", IPQ_set_verdict, METH_VARARGS, IPQ_set_verdict__doc__},
    {NULL, NULL}		/* Sentinel */
};

static PyObject *
IPQ_getattr(PyObject *self, char *name)
{
    return Py_FindMethod(IPQ_methods, self, name);
}


/* Object properties */

static PyTypeObject IPQType = {
    PyObject_HEAD_INIT(NULL)
    0,
    "IPQ",
    sizeof(IPQObject),
    0,
    IPQ_dealloc,		/* tp_dealloc */
    0,				/* tp_print */
    IPQ_getattr,		/* tp_getattr */
    0,				/* tp_setattr */
    0,				/* tp_compare */
    0,				/* tp_repr */
    0,				/* tp_as_number */
    0,				/* tp_as_sequence */
    0,				/* tp_as_mapping */
    0,				/* tp_hash */
};


/* Module stuff */

static PyMethodDef ipqueue_methods[] = {
    {"new", new_IPQObject, METH_VARARGS, new_IPQObject__doc__},
    {"IPQ", new_IPQObject, METH_VARARGS, new_IPQObject__doc__},
    {NULL, NULL, 0, NULL}	/* Sentinel */
};

static char ipqueue_doc[] = "ip_queue module";

DL_EXPORT(void)
initipqueue(void)
{
    PyObject *m, *d;

    IPQType.ob_type = &PyType_Type;
    IPQType.tp_doc = "Netfilter userspace IP_Queue class";
    ipqueue_error = PyErr_NewException("ipqueue.error", NULL, NULL);

    m = Py_InitModule3("ipqueue", ipqueue_methods, ipqueue_doc);
    d = PyModule_GetDict(m);
    PyDict_SetItemString(d, "IPQ_COPY_NONE",
			 Py_BuildValue("i", IPQ_COPY_NONE));
    PyDict_SetItemString(d, "IPQ_COPY_META",
			 Py_BuildValue("i", IPQ_COPY_META));
    PyDict_SetItemString(d, "IPQ_COPY_PACKET",
			 Py_BuildValue("i", IPQ_COPY_PACKET));

    PyDict_SetItemString(d, "NF_DROP",         Py_BuildValue("i", NF_DROP));
    PyDict_SetItemString(d, "NF_ACCEPT",       Py_BuildValue("i", NF_ACCEPT));
    PyDict_SetItemString(d, "NF_STOLEN",       Py_BuildValue("i", NF_STOLEN));
    PyDict_SetItemString(d, "NF_QUEUE",        Py_BuildValue("i", NF_QUEUE));
    PyDict_SetItemString(d, "NF_REPEAT",       Py_BuildValue("i", NF_REPEAT));

    PyDict_SetItemString(d, "PACKET_ID",       Py_BuildValue("i", 0));
    PyDict_SetItemString(d, "MARK",            Py_BuildValue("i", 1));
    PyDict_SetItemString(d, "TIMESTAMP",       Py_BuildValue("i", 2));
    PyDict_SetItemString(d, "HOOK",            Py_BuildValue("i", 3));
    PyDict_SetItemString(d, "INDEV_NAME",      Py_BuildValue("i", 4));
    PyDict_SetItemString(d, "OUTDEV_NAME",     Py_BuildValue("i", 5));
    PyDict_SetItemString(d, "HW_PROTOCOL",     Py_BuildValue("i", 6));
    PyDict_SetItemString(d, "HW_TYPE",         Py_BuildValue("i", 7));
    PyDict_SetItemString(d, "HW_ADDR",         Py_BuildValue("i", 8));
    PyDict_SetItemString(d, "PAYLOAD",         Py_BuildValue("i", 9));

    /* No need to check the error here, the caller will do that */
}     
