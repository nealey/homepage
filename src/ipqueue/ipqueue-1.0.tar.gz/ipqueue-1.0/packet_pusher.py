#! /usr/bin/python2.2

import ipqueue
import iputils

rewrite = 1

q = ipqueue.IPQ(ipqueue.IPQ_COPY_PACKET)
while 1:
    p = q.read()
    tcp = iputils.TCP(p[ipqueue.PAYLOAD])
    print "Got %s -> %s on hook %d" % (iputils.ntoa(tcp.saddr),
                                       iputils.ntoa(tcp.daddr),
                                       p[ipqueue.HOOK])

    if rewrite and p[ipqueue.HOOK] == 0:
        tcp.daddr = iputils.aton("10.1.1.2")
        tcp.th_dport = 25
        q.set_verdict(p[0], ipqueue.NF_ACCEPT, tcp.to_str())
    else:
        q.set_verdict(p[0], ipqueue.NF_ACCEPT)
    
