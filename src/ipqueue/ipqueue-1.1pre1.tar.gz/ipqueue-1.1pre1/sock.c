/* sock.c -- server-side socket stuff
 *
 * Description: server-side low-level socket initialization
 * Author: Neale Pickett <neale@lanl.gov>
 * Time-stamp: <99/10/22 11:44:20 neale>
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/types.h>

#ifndef BACKLOG
#define BACKLOG 10
#endif

#ifndef INSIZE
#define INSIZE 8192
#endif

#ifndef SOCK_TIMEOUT
#define SOCK_TIMEOUT 5
#endif

/** Print a formatted string to a file descriptor.
 *
 * @param   fd   File descriptor to print to
 * @param    fmt    Format string (like {\tt sprintf()})
 * @param   ...         Variables (like {\tt sprintf()})
 * @return   Same thing {\tt sprintf()} would have
 */
int
fdprintf(int fd, char *fmt, ...)
{
  char s[256];			/* Yeah, yeah, it's fixed.  Sue me. */
  int retval;
  va_list ap;

  va_start(ap, fmt);
  retval = vsnprintf(s, 255, fmt, ap);
  va_end(ap);

  write(fd, s, ((retval==-1)?255:retval));

  return retval;
}


/** Begin listening on the specified port.
 *
 * @param   port_num   What port number to listen on
 * @return   File descriptor, or -1 on error
 */
int
open_tcp_port(int port_num)
{
  int sockfd;
  int opt;
  struct sockaddr_in server;
  

  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    syslog(LOG_ERR, "socket: %m");
    return -1;
  }

  /* Set the socket options so that the address may be reused.  That is,
  * allow somoene to reuse the port immediately, should this daemon
  * terminate ungracefully.  A lot of programs would do well to steal
  * these four lines of code. */
  opt = 1;
  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *) &opt,
		 sizeof(opt)) < 0) {
    syslog(LOG_ERR, "setsockopt: %m");
    return -1;
  }
  
  /* bind the port */
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons(port_num);
  if (bind(sockfd, (struct sockaddr *)&server, sizeof(server))) {
    syslog(LOG_ERR, "bind: %m");
    close(sockfd);
    return -1;
  }

  if (listen(sockfd, BACKLOG)) {
    syslog(LOG_ERR, "listen: %m");
    close(sockfd);
    return -1;
  }

  return sockfd;
}


/** Make the socket behave sanely (sigh).
 *
 * @param  conn  Socket to fix
 */
void
sanitize_socket(int conn)
{
  struct linger l_time;

  /* Close on exec */
  fcntl(conn, F_SETFD, 1);

#if 0				/* Turns out this is a bad idea */
  /* Don't wait around if the connection is closed */
  l_time.l_onoff = 1;
  l_time.l_linger = 0;
  setsockopt(conn, SOL_SOCKET, SO_LINGER, &l_time,
	     sizeof(struct linger));
#endif
}

#if 0
/** Read a line from a socket connection.
 *
 * {\bf This code is untested!}
 *
 * @param   conn   Socket connection to read
 * @return  The line read (this needs to be {\tt free()}d) or NULL if the connection was closed or timed out
 */
char *
read_line(int conn)
{
  int inlen;
  char input[INSIZE];
  char *output;
  static char *buffer = NULL;

  if (buffer == NULL) {
    buffer = (char *)malloc(sizeof(char) * 1);
    buffer[0] = '\0';
  }
  input[0] = '\0';

  while ((output = first_in_str(buffer, '\n')) == NULL) {
    {
      /* Call select so that we can do the timeout stuff */
      
      fd_set rfds;
      struct timeval tv;
      
      /* Watch for input on the socket. */
      FD_ZERO(&rfds);
      FD_SET(conn, &rfds);

      /* Wait up to TIMEOUT seconds. */
      tv.tv_sec = SOCK_TIMEOUT;
      tv.tv_usec = 0;
      
      if (! select(1, &rfds, NULL, NULL, &tv)) {
	return NULL;
      }
      /* Don't rely on the value of tv now! */
    }

    inlen = read(conn, input, INSIZE - 1);
    
    if (inlen == 0) {
      return NULL;
    }
    input[inlen] = '\0';
    buffer = append(buffer, input);
  }

  {
    char *tmp;

    tmp = buffer;
    buffer = strdup(strchr(buffer, '\n') + 1);
    free(tmp);
  }

  return output;
}
#endif
