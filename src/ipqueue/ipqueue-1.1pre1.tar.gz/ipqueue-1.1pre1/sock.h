#ifndef SOCK_H
#define SOCK_H

int fdprintf(int fd, char *fmt, ...);
int open_tcp_port(int port_num);
void sanitize_socket(int conn);
char *read_line(int conn);

#endif
