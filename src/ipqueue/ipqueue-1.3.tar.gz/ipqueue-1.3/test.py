#! /usr/bin/env python

import ipqueue

q = ipqueue.IPQ(ipqueue.IPQ_COPY_PACKET)
print "fileno is", q.fileno()
while 1:
    t = q.read()
    print "I read a packet:", t
    print "Accept returned:", q.set_verdict(t[0], ipqueue.NF_ACCEPT)
