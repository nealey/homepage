#! /usr/bin/env python

from distutils.core import setup, Extension

ipqueue = Extension('ipqueue',
                    sources = ['ipqueue.c'],
                    include_dirs = ['/usr/include/libipq'],
                    libraries = ['ipq'])

setup (name = 'ipqueue',
       version = '1.4',
       author = 'Neale Pickett',
       author_email = 'neale@woozle.org',
       description = 'ip_queue routines from netfilter',
       long_description = 'Python wrapper around libipq routines for userspace'
                          'packet manipulation.  You could use this to build a'
                          'pythonic firewall, router, packet sniffer, etc.',
       ext_modules = [ipqueue],
       license = 'GPL',
       platforms = ['Linux'],
       url = 'http://woozle.org/neale/src/py-ipqueue')
