/** bouncerbob
 *
 * Bouncerbob tells you where you were going, for those times when you
 * need to know.
 *
 * This is intended to run on a machine set up to be a router.  It just
 * proves that you can do transparent proxying on a Linux 2.4 router.
 *
 * Run Bouncerbob as root.  Then, set up the ports you want to bounce
 * with the following command:
 *
 *   iptables -t nat -A PREROUTING -p tcp -m tcp --dport [PORT]
 *            -j REDIRECT --to-port 65000
 *
 * where PORT is the destination port you want Bouncerbob to squat on.
 */


#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netfilter_ipv4.h>

#include "sock.h"		/* boilerplate def of open_tcp_port */

int
main(int argc, char *argv[])
{
  int server;

  server = open_tcp_port(65000);
  if (-1 == server) {
    perror("open_tcp_port");
    return 1;
  }

  while (1) {
    int s;
    struct sockaddr_in addr;
    int addr_size = sizeof(addr);

    s = accept(server, (struct sockaddr *)&addr, &addr_size);
    if (-1 == s) {
      perror("accept");
      return 1;
    }

    {
      struct sockaddr_in orig_addr;
      int oaddr_size = sizeof(orig_addr);
      char buf[256];
      int buflen;
      int ret;

      ret = getsockopt(s, SOL_IP, SO_ORIGINAL_DST,
		       &orig_addr, &oaddr_size);
      if (-1 == ret) {
	perror("getsockopt");
	strcpy(buf, "Sorry buddy, perror\n");
	buflen = strlen(buf);
      } else {
	buflen = snprintf(buf, 255, "Dest was %s:%d\n",
			  inet_ntoa(orig_addr.sin_addr),
			  ntohs(orig_addr.sin_port));
      }
      write(s, buf, buflen);
      close(s);
    }
  }
  return 0;
}
