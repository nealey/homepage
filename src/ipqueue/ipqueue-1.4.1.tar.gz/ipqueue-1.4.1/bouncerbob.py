#! /usr/bin/env python

"""This program isn't finished yet.

Bouncerbob tells you where you were going, for those times when you
need to know.

This is intended to run on a machine set up to be a router.  It just
proves that you can do transparent proxying on a Linux 2.4 router.

Run Bouncerbob as root.  Then, set up the ports you want to bounce
with the following command:

    iptables -t nat -A PREROUTING -p tcp -m tcp --dport [PORT]
          -j REDIRECT --to-port 65000

where PORT is the destination port you want Bouncerbob to squat on.

"""


import socket
import SocketServer
import struct

# from /usr/include/linux/netfilter_ipv4.h
SO_ORIGINAL_DST = 80

def ntoa(n):
    a = "%d.%d.%d.%d" % ((n >> 24) % 256,
                         (n >> 16) % 256,
                         (n >>  8) % 256,
                         (n >>  0) % 256)
    return a

def orig_addrs(sock):
    dst = sock.getsockopt(socket.SOL_IP, SO_ORIGINAL_DST, 16)
    # It's not really clear to me where saddr and sport are being added
    # to the value we're returned.  I think it may be failure to
    # initialize a stack variable in nf_conntrack_core.c.  Regardless,
    # it's there, so we'll use it.
    (sin_family, dport, daddr, saddr, sport, proto) = \
                 struct.unpack("!HHLLHH", dst)
    return ((ntoa(saddr), sport), (ntoa(daddr), dport))
    


class ThreadingTCPServer(SocketServer.TCPServer):
    def server_bind(self):
        print "Wooga!"
        self.socket.bind(self.server_address)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

class BouncerRequestHandler(SocketServer.BaseRequestHandler):
    def handle(self):
        self.request.send("Hi!\n")
        addrs = orig_addrs(self.request)
        print addrs


srv = ThreadingTCPServer(("", 65000), BouncerRequestHandler)
srv.serve_forever()
