#! /usr/bin/env python

import struct
import sys

TH_FIN  = 0x01
TH_SYN  = 0x02
TH_RST  = 0x04
TH_PUSH = 0x08
TH_ACK  = 0x10
TH_URG  = 0x20
SOL_TCP = 6
SOL_UDP = 17

def unpack_nybbles(byte):
    return (byte >> 4, byte & 0x0F)

def pack_nybbles(hi, lo):
    return (hi << 4 | lo)

def ntoa(n):
    a = "%d.%d.%d.%d" % ((n >> 24) % 256,
                         (n >> 16) % 256,
                         (n >>  8) % 256,
                         (n >>  0) % 256)
    return a

def aton(a):
    parts = a.split(".")
    n = reduce(lambda x, y: (x<<8) + y, map(long, parts))
    return n

class IPv4:
    """
struct iphdr
  {
#if __BYTE_ORDER == __LITTLE_ENDIAN
    unsigned int ihl:4;
    unsigned int version:4;
#elif __BYTE_ORDER == __BIG_ENDIAN
    unsigned int version:4;
    unsigned int ihl:4;
#else
# error "Please fix <bits/endian.h>"
#endif
    u_int8_t tos;
    u_int16_t tot_len;
    u_int16_t id;
    u_int16_t frag_off;
    u_int8_t ttl;
    u_int8_t protocol;
    u_int16_t check;
    u_int32_t saddr;
    u_int32_t daddr;
    /*The options start here. */
  };
"""
    def __init__(self, data):
        (ihlvers,
         self.tos,
         self.tot_len,
         self.id,
         self.frag_off,
         self.ttl,
         self.protocol,
         self.check,
         self.saddr,
         self.daddr) = struct.unpack("!BBHHHBBHLL", data[:20])
        (self.version, self.ihl) = unpack_nybbles(ihlvers)
        length = self.ihl * 4

        self.options = data[20:length]
        self.payload = data[length:]

    def src_ip(self):
        return ntoa(self.saddr)

    def dst_ip(self):
        return ntoa(self.daddr)

    def iphdr_len(self):
        return 20 + len(self.options)

    def iphdr_to_str(self):
        ihlvers = pack_nybbles(self.version, (self.iphdr_len() / 4))

        str = struct.pack("!BBHHHBBHLL",
                          ihlvers,
                          self.tos,
                          self.tot_len,
                          self.id,
                          self.frag_off,
                          self.ttl,
                          self.protocol,
                          self.check,
                          self.saddr,
                          self.daddr)
        str = str + self.options
        return str


    def to_str(self):
        return self.iphdr_to_str() + self.payload

IP = IPv4
IP4 = IPv4


class IPv6:
    def __init__(self, data):
        (self.v_ds_flow,
         self.plen,
         self.nxt,
         self.hlim,
         self.src,
         self.dst) = struct.unpack("!IHBB16s16s", data[:40])
        self.payload = data[40:]

    def __getattr__(self, name):
        if name == 'v':
            return self.v_ds_flow >> 28
        elif name == 'ds':
            return (self.v_ds_flow >> 20) & 0xff
        elif name == 'flow':
            return self.v_ds_flow & 0xfffff
        else:
            raise AttributeError

    def __setattr__(self, name, val):
        if name == 'v':
            self.v_ds_flow = (self.v_ds_flow & ~0xf0000000L) | (val << 28)
        elif name == 'ds':
            self.v_ds_flow = (self.v_ds_flow & ~0xff00000L) | (val << 20)
        elif name == 'flow':
            self.v_ds_flow = (self.v_ds_flow & ~0xfffff) | (val & 0xfffff)
        else:
            self.__dict__[name] = val

    def ip6hdr_to_str(self):
        return struct.pack("!IHBB16s16s",
                           self.v_ds_flow,
                           self.plen,
                           self.nxt,
                           self.hlim,
                           self.src,
                           self.dst)

    def __str__(self):
        return self.ip6hdr_to_str() + self.payload

IP6 = IPv6


class UDP(IP):
    """
struct udphdr
  {
    u_int16_t th_sport;         /* source port */
    u_int16_t th_dport;         /* destination port */
};
"""
    def __init__(self, data):
        IP.__init__(self, data)
        if self.protocol != SOL_UDP:
            raise ValueError("Not a UDP packet!")
        udpdata = self.payload

        (self.th_sport,
         self.th_dport,
         self.th_len,
         self.th_check) = struct.unpack("!HHHH", udpdata[:8])
        self.payload = udpdata[8:]

    def udphdr_to_str(self):
        s = struct.pack("!HHHH",
                        self.th_sport,
                        self.th_dport,
                        self.th_len,
                        self.th_check)
        return s

    def to_str(self):
        return self.iphdr_to_str() + self.udphdr_to_str() + self.payload


class TCP(IP):
    """
struct tcphdr
  {
    u_int16_t th_sport;         /* source port */
    u_int16_t th_dport;         /* destination port */
    tcp_seq th_seq;             /* sequence number */
    tcp_seq th_ack;             /* acknowledgement number */
#  if __BYTE_ORDER == __LITTLE_ENDIAN
    u_int8_t th_x2:4;           /* (unused) */
    u_int8_t th_off:4;          /* data offset */
#  endif
#  if __BYTE_ORDER == __BIG_ENDIAN
    u_int8_t th_off:4;          /* data offset */
    u_int8_t th_x2:4;           /* (unused) */
#  endif
    u_int8_t th_flags;
#  define TH_FIN        0x01
#  define TH_SYN        0x02
#  define TH_RST        0x04
#  define TH_PUSH       0x08
#  define TH_ACK        0x10
#  define TH_URG        0x20
    u_int16_t th_win;           /* window */
    u_int16_t th_sum;           /* checksum */
    u_int16_t th_urp;           /* urgent pointer */
};
"""
    def __init__(self, data):
        IP.__init__(self, data)
        if self.protocol != SOL_TCP:
            raise ValueError("Not a TCP packet!")
        tcpdata = self.payload

        (self.th_sport,
         self.th_dport,
         self.th_seq,
         self.th_ack,
         x2off,
         self.th_flags,
         self.th_win,
         self.th_sum,
         self.th_urp) = struct.unpack("!HHLLBBHHH", tcpdata[:20])
        (self.th_off, self.th_x2) = unpack_nybbles(x2off)
        length = self.th_off * 4
        
        self.th_options = tcpdata[20:length]
        self.payload = tcpdata[length:]

    def tpchdr_len(self):
        return 20 * len(self.options)

    def tcphdr_to_str(self):
        x2off = pack_nybbles(self.th_off, self.th_x2)
        s = struct.pack("!HHLLBBHHH",
                        self.th_sport,
                        self.th_dport,
                        self.th_seq,
                        self.th_ack,
                        x2off,
                        self.th_flags,
                        self.th_win,
                        self.th_sum,
                        self.th_urp)
        s = s + self.th_options
        return s

    def to_str(self):
        return self.iphdr_to_str() + self.tcphdr_to_str() + self.payload
        
