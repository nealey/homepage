/* ZSafe Dump
 *
 * Copyright (C) 2003 Neale Pickett <neale@woozle.org>
 * Large portions Copyright (C) 2002 Carsten Schneider <CarstenSchneider@t-online.de>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "krc2.h"

// number of fields for one entry
#define FIELD_SIZE 7

enum {
    PWERR_GOOD = 0,             // success
    PWERR_OPEN,         // can't open filedescriptor / can't create file
    PWERR_PERM,                 // permissions are bad
    PWERR_SYML,                 // is a symlink
    PWERR_STAT,                 // can't get file status
    PWERR_DATA                  // can't read correct data
};

class ZSafe
{
public:
    char *filename;

    long load_buffer_length;
    long save_buffer_length;

    /** password for the file */
    char *m_password;
    /** globals needed for file loading */
    int lastcount, size;
    /** these three are needed in all save functions and initialized in save _init() */
    FILE *fd;
    unsigned short iv[4];
    char *buffer;
    /** these two are global because save_entry() and save_finalize() both n eed them */
    int bufferIndex;
    unsigned short plaintext[4];

    int loadInit(const char* filename, const char *password);
    int loadEntry(char *entry[4]);
};

int ZSafe::loadInit(const char* _filename, const char *password)
{
    unsigned int j = 0;
    unsigned int keylength=0;
    int count=0, count2=0, count3=0;
    unsigned char charbuf[8];
    unsigned short ciphertext[4];
    char key[128];
    Krc2* krc2 = new Krc2();

    fd = fopen (_filename, "rb");
    if (NULL == fd) {
        perror("fopen");
        return PWERR_OPEN;
    }

    fseek(fd, 0, SEEK_END);
    load_buffer_length = ftell(fd);
    fseek(fd, 0, SEEK_SET);
    load_buffer_length = ((load_buffer_length / 1024)+1) * 1024 * 2;

    buffer = (char *)malloc(load_buffer_length);
    for (j = 0; password[j] != '\0'; j++) {
        key[j] = password[j];
    }
    keylength = j;
    krc2->rc2_expandkey (key, keylength, 128);

    printf ("LoadInit() read1");
    size = fread ((unsigned char *) (charbuf + count), sizeof(unsigned char), 8, fd);

    if (size < 8)
        return PWERR_DATA;

    for (count = 0; count < 4; count++) {
        count2 = count << 1;
        iv[count] = charbuf[count2] << 8;
        iv[count] += charbuf[count2 + 1];
    }

    size = 0;
    bufferIndex = 0;
    printf ("LoadInit() read2");
    while ((count = fread ((unsigned char *) (charbuf), sizeof(unsigned char), 8, fd)) > 0) {
        while (count < 8) {
            count2 = fread ((unsigned char *) (charbuf + count), sizeof(unsigned char), 8, fd);
            if (count2 == 0) {
                return PWERR_DATA;
            }
            count += count2;
        } /* while (count < 8) */

        size += 8;
        for (count2 = 0; count2 < 8; count2 += 2) {
            count3 = count2 >> 1;
            ciphertext[count3] = charbuf[count2] << 8;
            ciphertext[count3] += charbuf[count2 + 1];

            plaintext[count3] = ciphertext[count3] ^ iv[count3];
            iv[count3] = plaintext[count3];
        } /* for (count2) */

        krc2->rc2_decrypt (plaintext);
        memcpy ((unsigned char *) (buffer + bufferIndex), plaintext, 8);
        bufferIndex += 8;
        buffer[bufferIndex + 1] = '\0';
    } /* while ((count = read (fileno (fd), (unsigned char *) charbuf, 8)) > 0) */
    size -= buffer[size - 1];
    lastcount = 0;

    /* This will point to the starting index */
    bufferIndex = 0;
    return PWERR_GOOD;
}

int ZSafe::loadEntry(char *entry[FIELD_SIZE])
{
	/* Strip off PKCS 5 padding
	 * Should check to make sure it's good here
	 */
    int count, count1=0;

    for (count = lastcount; count < size; count++) {
        if ((unsigned char) (buffer[count]) == 255) {
            if (buffer[bufferIndex] == '\0') {
                bufferIndex++;
            }
            entry[count1] = (char *) malloc (count - bufferIndex + 1);
            memcpy (entry[count1], (unsigned char *) (buffer + bufferIndex), count - bufferIndex);
            entry[count1][count - bufferIndex] = '\0';
            count++;
            bufferIndex = count;
            count1++;
            if (count1 == FIELD_SIZE) {
                lastcount = count;
                return 1;
            }
        } /* if ((unsigned char) (buffer[count]) == 255) */
    } /* for (count = 0; count < size; count++) */

    return 2;
}


int
main(int argc, char **argv)
{
    ZSafe z = ZSafe();
    int   retval;
    char* entry[FIELD_SIZE];

    z.m_password = getpass("Enter your password: ");
    if (2 != argc) {
        retval = z.loadInit("passwords.zsf", z.m_password);
    } else {
        retval = z.loadInit(argv[1], z.m_password);
    }
    if (PWERR_GOOD != retval) {
        return retval;
    }

    retval = z.loadEntry(entry);
    while (retval == 1) {
        for (int count = 0; count < FIELD_SIZE; count++) {
            printf("%s\t", entry[count]);
            free(entry[count]);
        }
        printf("\n");
        retval = z.loadEntry(entry);
    }

    return 0;
}
